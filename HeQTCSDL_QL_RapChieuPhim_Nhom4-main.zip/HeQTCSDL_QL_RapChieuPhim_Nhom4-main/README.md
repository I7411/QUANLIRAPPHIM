# HeQTCSDL_QL_RapChieuPhim_Nhom4
Đề tài ứng dụng quản lý rạp chiếu phim
